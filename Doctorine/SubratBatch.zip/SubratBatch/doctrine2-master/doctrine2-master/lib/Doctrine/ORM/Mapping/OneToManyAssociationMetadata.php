<?php

declare(strict_types=1);

namespace Doctrine\ORM\Mapping;

class OneToManyAssociationMetadata extends ToManyAssociationMetadata
{
}

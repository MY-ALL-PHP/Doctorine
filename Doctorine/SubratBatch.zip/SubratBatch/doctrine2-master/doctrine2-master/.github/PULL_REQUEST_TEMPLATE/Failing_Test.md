---
name: 🐞 Failing Test
about: You found a bug and have a failing Unit or Functional test? 🔨
---

### Failing Test

<!-- Fill in the relevant information below to help triage your issue. -->

|    Q        |   A
|------------ | ------
| BC Break    | yes/no
| Version     | x.y.z


#### Summary

<!-- Provide a summary of the failing scenario. -->


<?php

declare(strict_types=1);

namespace Doctrine\ORM\Annotation;

/**
 * @Annotation
 * @Target("METHOD")
 */
final class PostPersist implements Annotation
{
}
